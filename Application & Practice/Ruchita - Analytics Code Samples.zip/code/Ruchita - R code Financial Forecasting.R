# You are a financial analyst and your boss is ready to give you a bit more responsibility 
# and allow you to interact directly with clients. 
# You are tasked with picking a stock to pitch to your first client. 
# You want to present a robust analysis of the stock of your choice. 
# Using the past 3 years of data, please write an R-script that answers the following: 

library(dplyr)
library(data.table) 
library(fBasics) 
library(fPortfolio)
library(tseries)
library(PortfolioAnalytics)
library(PerformanceAnalytics) 
library(quantmod) 
library(xts) 

options(scipen=999)
set.seed(2020)

setwd("C:/PERSONAL/USA/DU Docs/MY COURSES/FIN 3500/Module 6")

getSymbols("ARW", from = "2019-05-20", to = "2022-05-20", src ="yahoo")
arrowprices <- ARW[,6]

arrowreturns <- dailyReturn(arrowprices)
colnames(arrowreturns) <- "ARROW"

# QUESTION 1
# Analyze the daily distribution of returns – plot the density function. 
# Does it look like it’s normally distributed?

arrowreturnsdensity <- density(arrowreturns$ARROW)
plot(arrowreturnsdensity, main = "Distribution of Arrow Stock Returns")
polygon(arrowreturnsdensity, col = "tomato")
# Yes, the distribution of the Stock Returns for Arrow do look normal. 
# We see a bell curve that forms.


# QUESTION 2
# Estimate the annual mean returns and annual standard deviation of returns.
arrowannualmu <- mean(arrowreturns$ARROW)*252 
arrowannualmu
arrowannualsigma <- sd(arrowreturns$ARROW)*sqrt(252) 
arrowannualsigma


# QUESTION 3
# Simulate the daily price path over the next 6 months (approximately 126 days) 
# using the estimates from (2) above and assuming that prices follow a lognormal distribution.
# Plot the outcome of the simulation.
p0 <- 122.80
deltat <- 1/126
z <- rnorm(n = 126, mean = 0, sd = 1) 
arrowmu <- mean(arrowreturns$ARROW)*126
arrowmu
arrowsigma <- sd(arrowreturns$ARROW)*sqrt(126) 
arrowsigma


arrowsimprice <- as.data.frame(matrix(NA, nrow = 127, ncol = 2))
colnames(arrowsimprice) <- c("time", "price")
arrowsimprice[1,1] <- 0
arrowsimprice[1,2] <- p0 
arrowsimprice

for(i in 1:126){
  arrowsimprice[i+1,1] <- i
  arrowsimprice[i+1,2] <- arrowsimprice[i,2]*exp((arrowmu-0.5*arrowsigma*arrowsigma)*deltat+arrowsigma*z[i]*sqrt(deltat))
}
arrowsimprice

plot(arrowsimprice$time, arrowsimprice$price, type = "l", main = "Arrow Simulated Prices", xlab = "Time", ylab = "Price", col = "blue", lwd = 2)




# QUESTION 4
# Simulate ten expected daily price paths like the one in (3) above
# and graph them on the same graph. 

p0 <- 122.80 
deltat <- 1/126
set.seed(2020) 
z <- rnorm(n = 126, mean = 0, sd = 1) 

arrowsimprice <- as.data.frame(matrix(NA, nrow = 127, ncol = 11))
colnames(arrowsimprice) <- c("time", paste0("price",1:10))
arrowsimprice[1,1] <- 0
arrowsimprice

for (j in 1:10){
  z <- rnorm(n = 126, mean = 0, sd = 1) 
  arrowsimprice[1,j+1] <- p0 
  for(i in 1:126){
    arrowsimprice[i+1,1] <- i
    arrowsimprice[i+1,j+1] <- arrowsimprice[i,j+1]*exp((arrowmu-0.5*arrowsigma*arrowsigma)*deltat+arrowsigma*z[i]*sqrt(deltat))
  }
}
arrowsimprice

colors<-rainbow(10)
price=c(paste0("price",1:10))
arrowpricepaths <- arrowsimprice[2:11]
plot(arrowsimprice$time, arrowsimprice$price1, type = "l", main = "Arrow All Simulated Prices", xlab = "Time", ylab = "Price",ylim=range(arrowpricepaths), col=colors[1], lwd = 2, lty = 1 )
for (j in 2:11){
  lines(arrowsimprice$time, arrowsimprice[,j], col = colors[j], lwd = 2, lty = 1)
}

# QUESTION 5
# Your client wants to invest a large amount into the stock you picked, 
# but they have a fairly short horizon of only 35 days. 
# You oversee risk management for your client and 
# decided to run a VaR analysis for the given horizon. 
# What is the worst-case scenario for the stock price 35 days from now (with 99% certainty)?


p0 <- 122.80
deltat <- 35/126 
arrowmu <- mean(arrowreturns$ARROW)*126 
arrowsigma <- sd(arrowreturns$ARROW)*sqrt(126) 

set.seed(2020)

z <- rnorm(n = 500, mean = 0, sd = 1)



arrowsimprice35 <- as.data.frame(matrix(NA, nrow = 500, ncol = 1))
colnames(arrowsimprice35) <- c("price35")


for (i in 1:500){
  arrowsimprice35[i,1]<-p0*exp((arrowmu-0.5*arrowsigma*arrowsigma)*deltat+arrowsigma*z[i]*sqrt(deltat))
}
arrowsimprice35

arrowsimprice35.den <- density(arrowsimprice35$price35)
plot(arrowsimprice35.den, main = "Empirical Distribution of the Simulated Prices")
polygon(arrowsimprice35.den, col = "green")


quantile(arrowsimprice35$price35,c(.01)) 