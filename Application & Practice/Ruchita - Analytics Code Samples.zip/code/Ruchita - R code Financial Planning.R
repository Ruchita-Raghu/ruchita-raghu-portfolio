# In this assignment, you are a financial advisor who is tasked with helping a client. 
# Your client is planning to invest their money in an equity-only portfolio and has already decided that their chosen stocks 
# are Bank of America Corp, Intel Corporation, Coca Cola Company, Walt Disney Company, Caterpillar Inc., and American Express Company. 
# However, the client needs your help deciding how much money they should invest in each stock.

# Use the past five years of historical data (from Oct 31, 2016 to Oct 31, 2021)

# QUESTION 1 
# To get a sense of the data, provide summary statistics of both the adjusted daily stock prices, and the monthly returns.

# Tickers - BAC, INTC, KO, DIS, CAT, AXP

# Load the required libraries/packages
library(dplyr) 
library(data.table) 
library(fBasics) 
library(fPortfolio) 
library(tseries) 
library(PortfolioAnalytics) 
library(PerformanceAnalytics) 
library(quantmod) 
library(xts) 

options(scipen=999) 


# Set the working directory to the desired location 
setwd("C:/PERSONAL/USA/DU Docs/MY COURSES/FIN 3500/Module 5")

# Get the stock prices
tickers <- c("BAC", "INTC", "KO", "DIS", "CAT", "AXP")
getSymbols(tickers, from = "2016-10-31", to = "2021-10-31", src = "yahoo")

# Adjusted Prices
BAC.adj<-BAC[,6] 
INTC.adj<-INTC[,6]
KO.adj<-KO[,6]
DIS.adj<-DIS[,6]
CAT.adj<-CAT[,6]
AXP.adj<-AXP[,6]

# monthly returns
bac.rets <- monthlyReturn(BAC.adj)
intc.rets <- monthlyReturn(INTC.adj)
ko.rets <- monthlyReturn(KO.adj)
dis.rets <- monthlyReturn(DIS.adj)
cat.rets <- monthlyReturn(CAT.adj)
axp.rets <- monthlyReturn(AXP.adj)

# Daily adjusted prices dataset
alladjprices <- cbind(BAC.adj, INTC.adj, KO.adj, DIS.adj, CAT.adj, AXP.adj)
colnames(alladjprices) <- tickers

# Monthly returns dataset
allmonthlyret <- cbind(bac.rets, intc.rets, ko.rets, dis.rets, cat.rets, axp.rets)
colnames(allmonthlyret) <- tickers 

# Summary stats 
adjpricessummary <- summary(alladjprices)
monretsummary <- summary(allmonthlyret)
adjpricessummary
monretsummary




# QUESTION 2
# Plot the daily stock prices for each stock in separate graphs. Use proper titles for each graph.

plot.xts(BAC.adj, main = "Bank of America Daily Prices")
plot.xts(INTC.adj, main = "Intel Corp Daily Prices")
plot.xts(KO.adj, main = "Coca Cola Daily Prices")
plot.xts(DIS.adj, main = "Walt Disney Daily Prices")
plot.xts(CAT.adj, main = "Caterpillar Daily Prices")
plot.xts(AXP.adj, main = "American Express Daily Prices")

# QUESTION 3
# Plot the "2017" daily stock prices for Bank of America and Intel Corporation in separate graphs.

plot.xts(BAC.adj["2017", ], main = "Bank of America Only 2017 Prices")
plot.xts(INTC.adj["2017", ], main = "Intel Corp Only 2017 Prices")


# QUESTION 4
# If the client would like to only take long positions and 
# wishes to have an efficient portfolio with the lowest risk possible (minimum variance portfolio), 
# how much do they need to invest in each asset?


allmonthlyret <- na.omit(allmonthlyret)
nassets <- ncol(allmonthlyret)
allmonthlyret <- timeSeries(allmonthlyret)

my.specs <- portfolioSpec()
my.specs
my.const <- "LongOnly"

minvar <- minvariancePortfolio(data = allmonthlyret, spec = my.specs, constraints = my.const)
minvar
minvar.weights <- getWeights(minvar)
minvar.weights


# QUESTION 5
# Provide a plot of the weights you obtained in part (4). Use proper title and axis labels for the graph.

barplot(minvar.weights, col = terrain.colors(nassets), main = "Min Variance Weights", ylab = "Percentage", xlab = "Stocks")


# QUESTION 6
# How much is the expected "ANNUAL" return and risk of the minimum variance portfolio?
#   Hint: Use "getTargetReturn" and "getTargetRisk" functions to extract the expected risk and return of the portfolio and save them. 
#   The output of "getTargetReturn" function reports "mean" and "mu". Pick "mean" as the expected portfolio return. 
#   The output of "getTargetRisk" includes 4 measures of risk. Pick "Sigma" as the measure of the portfolio expected risk. 
#   Note that since we are using monthly returns for portfolio optimization in this problem all the estimated returns and risk values are on a monthly basis. 
#   To convert monthly returns to annual values, you should multiply the expected returns by 12 (number of months in one year) and 
#   multiply expected risk by square root of 12 
# (we would multiply by 252 and square root of 252 if the daily returns were used to construct the portfolios.)

annualret <- getTargetReturn(minvar)[1]*12
annualrisk <- getTargetRisk(minvar)[2]*sqrt(12)
annualret
annualrisk



# QUESTION 7
# If the client would like to go long in each stock and wishes to have an efficient portfolio with the highest Sharpe Ratio (optimal portfolio), 
# how much do they need to invest in each asset, assuming the monthly risk-free rate is 0.1%?
# NOTE: RESETTING SPECS

const7 <- "LongOnly"
my.specs <- portfolioSpec()
setRiskFreeRate(my.specs) <- 0.001
my.specs

optimal <- tangencyPortfolio(data = allmonthlyret, spec = my.specs, constraints = const7)
optimal
optimal.weights <- getWeights(optimal)
optimal.weights



# QUESTION 8
# How much is the expected "annual" return and risk of the optimal portfolio obtained from part 7?

optannualret <- getTargetReturn(optimal)[1]*12
optannualrisk <- getTargetRisk(optimal)[2]*sqrt(12)
optannualret
optannualrisk



# QUESTION 9
# Provide a bar plot of the weights corresponding to the portfolios on the efficient frontier set. 
# Also, provide a plot of the efficient frontier set along with the tangency portfolio, global min variance portfolio, equal weights portfolio, and the capital market line.
# NOTE: RESETTING SPECS
my.specs <- portfolioSpec()

efctfrontset <- portfolioFrontier(allmonthlyret)
efctfrontset

efctfront.weights <- getWeights(efctfrontset)
barplot(t(efctfront.weights), main = "Efficient Frontier Weights", col = rainbow(nassets), xlab = "Portfolios", ylab = "Weights")

plot.fPORTFOLIO(efctfrontset, which = c(1,2,3,5))

# QUESTION 10
# If the client would like to go long in each stock and wishes to have an efficient portfolio with a target annual return of 15% 
# (equivalent to 15%/12=1.25% per month), how much does she need to invest in each stock? 
# What is the expected annual risk of the portfolio?
# NOTE: RESETTING SPECS

my.specs <- portfolioSpec()
const10 <- "LongOnly"
setTargetReturn(my.specs) <- 0.0125


targetefctportfolio <- efficientPortfolio(data = allmonthlyret, spec = my.specs, constraints = const10)

targetefct.weights <- getWeights(targetefctportfolio)
targetefct.weights

tgtannualrisk <- getTargetRisk(targetefctportfolio)[2]*sqrt(12)
tgtannualrisk


# QUESTION 11
# If the client works with a broker who allows her to short sell stocks, 
# how much should she invest in each stock to achieve highest Sharpe Ratio portfolio, 
# if the monthly risk-free rate is 0? How much is the expected annual risk and return of the portfolio in this case? 
# Provide a bar plot of the optimal weights.
# NOTE: RESETTING SPECS

my.specs <- portfolioSpec()
setSolver(my.specs) <- "solveRshortExact"
setRiskFreeRate(my.specs) <- 0
my.specs
const11 <- "Short"

optimal.short <- tangencyPortfolio(data = allmonthlyret, spec = my.specs, constraints = const11)
optimal.short

optimal.short.weights <- getWeights(optimal.short)
optimal.short.weights

optshort.annualret <- getTargetReturn(optimal.short)[1]*12
optshort.annualrisk <- getTargetRisk(optimal.short)[2]*sqrt(12)
optshort.annualret
optshort.annualrisk


barplot(optimal.short.weights, col = terrain.colors(nassets), main = "Optimal Short Portfolio Weights", ylab = "Percentage", xlab = "Stocks")


# QUESTION 12
# Put the expected annual returns and risk for the long only scenario calculated in part (8) and the short scenario values calculated in part (11) in one matrix. 
# What changes do you see when short selling is allowed?


annual.retrisk.matrix <- as.data.frame(matrix(NA, nrow = 2, ncol = 3))
colnames(annual.retrisk.matrix) <- c("Portfolio", "Return", "Risk")
annual.retrisk.matrix

annual.retrisk.matrix[1,1] <- c("Optimal Long")
annual.retrisk.matrix[2,1] <- c("Optimal Short")
annual.retrisk.matrix[1,2] <- optannualret
annual.retrisk.matrix[2,2] <- optshort.annualret
annual.retrisk.matrix[1,3] <- optannualrisk
annual.retrisk.matrix[2,3] <- optshort.annualrisk

annual.retrisk.matrix

# QUESTION 13
# Assume the client would like to invest at least 15% in each of Bank of America and Coca Cola stocks but no more than 50% in each, 
# and also the client does not want to put more than 30% in Intel. If the client's goal is to form the optimal portfolio (highest Sharpe Ratio), 
# how much does she need to invest in each stock? 
# Answer the same question if the client is seeking to form the global minimum variance portfolio. 
# Risk free rate is assumed to be 0. Provide side-by-side pie chart of the weights for these two portfolios with proper titles.
# NOTE: RESETTING SPECS

my.specs <- portfolioSpec()
const13 <- c("minW[c(1,3)] = 0.15", "maxW[c(1,3)] = 0.50", "maxW[c(2)] = 0.30")
const13


opt.withconst <- tangencyPortfolio(data = allmonthlyret, spec = my.specs, constraints = const13)
opt.withconst

opt.withconst.weights <- getWeights(opt.withconst)
opt.withconst.weights


setRiskFreeRate(my.specs) <- 0
const13
mv.withconst <- minvariancePortfolio(data = allmonthlyret, spec = my.specs, constraints = const13)
mv.withconst

mv.withconst.weights <- getWeights(mv.withconst)
mv.withconst.weights

par(mfrow = c(1,2))
weightsPie(opt.withconst, col = rainbow(nassets))
  title("Weights for optimal portfolio")
weightsPie(mv.withconst, col = terrain.colors(nassets))
  title("Weights for minimum variance portfolio")
  




# QUESTION 14
# Assume the client would like to invest exactly 40% of her money in the group consisting of Intel and Walt Disney, 
# at least 20% of her money in the group consisting of Caterpillar and American Express, 
# and no more than 30% of her money in the group consisting of Caterpillar and Bank of America. 
# If the client's goal is to form the optimal portfolio (highest Sharpe Ratio), how much does she need to invest in each stock? 
# Answer the same question if the client's goal is to form the global minimum variance portfolio. 
# Risk free rate is 0 (Hint: You learned in class about "minsumW”, “maxsumW”, etc. The equal sum constraint is done through "eqsumW" option.). 
# Provide side-by-side pie chart of the weights for these two portfolios.   
# NOTE: RESETTING SPECS


my.specs <- portfolioSpec()
my.specs
const14 <- c("eqsumW[c(2,4)]=0.40", "minsumW[c(5,6)]=0.20", "maxsumW[c(5,1)]=0.30")
const14

optimal.combined <- tangencyPortfolio(data = allmonthlyret, spec = my.specs, constraints = const14)
optimal.combined

optimal.combined.weights <- getWeights(optimal.combined)
optimal.combined.weights

setRiskFreeRate(my.specs) <- 0
my.specs
const14

mv.withcombined <- minvariancePortfolio(data = allmonthlyret, spec = my.specs, constraints = const14)
mv.withcombined

mv.withcombined.weights <- getWeights(mv.withcombined)
mv.withcombined.weights

par(mfrow = c(1,2))
weightsPie(optimal.combined, col = rainbow(nassets))
  title("Weights for optimal portfolio")
weightsPie(mv.withcombined, col = terrain.colors(nassets))
  title("Weights for minimum variance portfolio")



# QUESTION 15
# Assume the client would like to invest at least 5% in each individual stock but does not wish to put more than 35% in the group consisting of 
# Bank of America, Intel, and Walt Disney. If the client's goal is to form the optimal portfolio (highest Sharpe Ratio), 
# how much does she need to invest in each stock? 
# Answer the same question if the client's goal is to form the global minimum variance portfolio. 
# Risk free rate is 0. 
# Provide side-by-side pie chart of the weights for these two portfolios.   
# NOTE: RESETTING SPECS

my.specs <- portfolioSpec()
const15 <- c("minW[c(1:nassets)]=0.05", "maxsumW[c(1,2,4)]=0.35")
my.specs
const15


optimal.combined2 <- tangencyPortfolio(data = allmonthlyret, spec = my.specs, constraints = const15)
optimal.combined2

optimal.combined2.weights <- getWeights(optimal.combined2)
optimal.combined2.weights


setRiskFreeRate(my.specs) <- 0
my.specs
const15

mv.withcombined2 <- minvariancePortfolio(data = allmonthlyret, spec = my.specs, constraints = const15)
mv.withcombined2

mv.withcombined2.weights <- getWeights(mv.withcombined2)
mv.withcombined2.weights

par(mfrow = c(1,2))
weightsPie(optimal.combined2, col = rainbow(nassets))
  title("Weights for optimal portfolio")
weightsPie(mv.withcombined2, col = terrain.colors(nassets))
  title("Weights for minimum variance portfolio")
